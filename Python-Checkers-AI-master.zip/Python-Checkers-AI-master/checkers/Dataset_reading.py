#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 17 09:07:34 2022

@author: saad
"""

import pandas as pd
df = pd.read_csv("/home/saad/.config/spyder-py3/Machine_learnine_Course_Content/avocado-prices/avocado.csv")
#print(df.head())
print("############################################################")
# print(df.head(3))
print("############################################################")
#print(df.tail(6))
print("############################################################")
#print(df['AveragePrice'].head())
#print("############################################################")
#print(df[df['region']=="Albany"])
##print("############################################################")
albany_df = df[df['region']=="Albany"]
print("############################################################")
print(albany_df.head())
print("############################################################")
print(albany_df.index)
print("############################################################")
# albany_df = albany_df.index
print("############################################################")
# print(albany_df)
albany_df = albany_df.set_index("Date")

# albany_df = albany_df.set_index("Date")
print("############################################################")
# albany_df.set_index("Date", inplace=True)
# albany_df.head()

albany_df['AveragePrice'].plot()

